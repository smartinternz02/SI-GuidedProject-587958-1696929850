package com.example.newsapp;

import java.lang.System;

@kotlin.Metadata(mv = {1, 7, 1}, k = 1, d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \'2\u00020\u0001:\u0001\'B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0012\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0014J\u0010\u0010\u001b\u001a\u00020\u00142\u0006\u0010\u001c\u001a\u00020\u001dH\u0016J\u0010\u0010\u001e\u001a\u00020\u00142\u0006\u0010\u001f\u001a\u00020 H\u0016J\u001e\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\u00072\f\u0010#\u001a\b\u0012\u0004\u0012\u00020%0$H\u0002J\b\u0010&\u001a\u00020\u0018H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\bR\u000e\u0010\t\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006("}, d2 = {"Lcom/example/newsapp/MainActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "fragmentAdapter", "Lcom/example/newsapp/adapters/FragmentAdapter;", "newsCategories", "", "", "[Ljava/lang/String;", "shimmerLayout", "Lcom/facebook/shimmer/ShimmerFrameLayout;", "tabLayout", "Lcom/google/android/material/tabs/TabLayout;", "totalRequestCount", "", "viewModel", "Lcom/example/newsapp/architecture/NewsViewModel;", "viewPager", "Landroidx/viewpager2/widget/ViewPager2;", "isNetworkAvailable", "", "context", "Landroid/content/Context;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateOptionsMenu", "menu", "Landroid/view/Menu;", "onOptionsItemSelected", "item", "Landroid/view/MenuItem;", "requestNews", "newsCategory", "newsData", "", "Lcom/example/newsapp/NewsModel;", "setViewPager", "Companion", "app_debug"})
public final class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private final java.lang.String[] newsCategories = {"Home", "business", "entertainment", "science", "sports", "technology", "health"};
    private com.example.newsapp.architecture.NewsViewModel viewModel;
    private com.google.android.material.tabs.TabLayout tabLayout;
    private androidx.viewpager2.widget.ViewPager2 viewPager;
    private com.example.newsapp.adapters.FragmentAdapter fragmentAdapter;
    private com.facebook.shimmer.ShimmerFrameLayout shimmerLayout;
    private int totalRequestCount = 0;
    @org.jetbrains.annotations.NotNull
    public static final com.example.newsapp.MainActivity.Companion Companion = null;
    @org.jetbrains.annotations.NotNull
    private static java.util.ArrayList<com.example.newsapp.NewsModel> generalNews;
    @org.jetbrains.annotations.NotNull
    private static java.util.List<com.example.newsapp.NewsModel> entertainmentNews;
    @org.jetbrains.annotations.NotNull
    private static java.util.List<com.example.newsapp.NewsModel> businessNews;
    @org.jetbrains.annotations.NotNull
    private static java.util.List<com.example.newsapp.NewsModel> healthNews;
    @org.jetbrains.annotations.NotNull
    private static java.util.List<com.example.newsapp.NewsModel> scienceNews;
    @org.jetbrains.annotations.NotNull
    private static java.util.List<com.example.newsapp.NewsModel> sportsNews;
    @org.jetbrains.annotations.NotNull
    private static java.util.List<com.example.newsapp.NewsModel> techNews;
    private static boolean apiRequestError = false;
    @org.jetbrains.annotations.NotNull
    private static java.lang.String errorMessage = "error";
    
    public MainActivity() {
        super();
    }
    
    @java.lang.Override
    protected void onCreate(@org.jetbrains.annotations.Nullable
    android.os.Bundle savedInstanceState) {
    }
    
    private final void requestNews(java.lang.String newsCategory, java.util.List<com.example.newsapp.NewsModel> newsData) {
    }
    
    private final void setViewPager() {
    }
    
    @java.lang.Override
    public boolean onCreateOptionsMenu(@org.jetbrains.annotations.NotNull
    android.view.Menu menu) {
        return false;
    }
    
    @java.lang.Override
    public boolean onOptionsItemSelected(@org.jetbrains.annotations.NotNull
    android.view.MenuItem item) {
        return false;
    }
    
    private final boolean isNetworkAvailable(android.content.Context context) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 7, 1}, k = 1, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR \u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR \u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\r\"\u0004\b\u0012\u0010\u000fR\u001a\u0010\u0013\u001a\u00020\u0014X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R*\u0010\u0019\u001a\u0012\u0012\u0004\u0012\u00020\u000b0\u001aj\b\u0012\u0004\u0012\u00020\u000b`\u001bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001fR \u0010 \u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\r\"\u0004\b\"\u0010\u000fR \u0010#\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\r\"\u0004\b%\u0010\u000fR \u0010&\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\'\u0010\r\"\u0004\b(\u0010\u000fR \u0010)\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b*\u0010\r\"\u0004\b+\u0010\u000f\u00a8\u0006,"}, d2 = {"Lcom/example/newsapp/MainActivity$Companion;", "", "()V", "apiRequestError", "", "getApiRequestError", "()Z", "setApiRequestError", "(Z)V", "businessNews", "", "Lcom/example/newsapp/NewsModel;", "getBusinessNews", "()Ljava/util/List;", "setBusinessNews", "(Ljava/util/List;)V", "entertainmentNews", "getEntertainmentNews", "setEntertainmentNews", "errorMessage", "", "getErrorMessage", "()Ljava/lang/String;", "setErrorMessage", "(Ljava/lang/String;)V", "generalNews", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "getGeneralNews", "()Ljava/util/ArrayList;", "setGeneralNews", "(Ljava/util/ArrayList;)V", "healthNews", "getHealthNews", "setHealthNews", "scienceNews", "getScienceNews", "setScienceNews", "sportsNews", "getSportsNews", "setSportsNews", "techNews", "getTechNews", "setTechNews", "app_debug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.ArrayList<com.example.newsapp.NewsModel> getGeneralNews() {
            return null;
        }
        
        public final void setGeneralNews(@org.jetbrains.annotations.NotNull
        java.util.ArrayList<com.example.newsapp.NewsModel> p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.List<com.example.newsapp.NewsModel> getEntertainmentNews() {
            return null;
        }
        
        public final void setEntertainmentNews(@org.jetbrains.annotations.NotNull
        java.util.List<com.example.newsapp.NewsModel> p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.List<com.example.newsapp.NewsModel> getBusinessNews() {
            return null;
        }
        
        public final void setBusinessNews(@org.jetbrains.annotations.NotNull
        java.util.List<com.example.newsapp.NewsModel> p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.List<com.example.newsapp.NewsModel> getHealthNews() {
            return null;
        }
        
        public final void setHealthNews(@org.jetbrains.annotations.NotNull
        java.util.List<com.example.newsapp.NewsModel> p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.List<com.example.newsapp.NewsModel> getScienceNews() {
            return null;
        }
        
        public final void setScienceNews(@org.jetbrains.annotations.NotNull
        java.util.List<com.example.newsapp.NewsModel> p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.List<com.example.newsapp.NewsModel> getSportsNews() {
            return null;
        }
        
        public final void setSportsNews(@org.jetbrains.annotations.NotNull
        java.util.List<com.example.newsapp.NewsModel> p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.util.List<com.example.newsapp.NewsModel> getTechNews() {
            return null;
        }
        
        public final void setTechNews(@org.jetbrains.annotations.NotNull
        java.util.List<com.example.newsapp.NewsModel> p0) {
        }
        
        public final boolean getApiRequestError() {
            return false;
        }
        
        public final void setApiRequestError(boolean p0) {
        }
        
        @org.jetbrains.annotations.NotNull
        public final java.lang.String getErrorMessage() {
            return null;
        }
        
        public final void setErrorMessage(@org.jetbrains.annotations.NotNull
        java.lang.String p0) {
        }
    }
}