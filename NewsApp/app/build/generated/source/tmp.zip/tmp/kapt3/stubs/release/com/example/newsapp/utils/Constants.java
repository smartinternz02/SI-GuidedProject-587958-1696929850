package com.example.newsapp.utils;

import java.lang.System;

@kotlin.Metadata(mv = {1, 7, 1}, k = 1, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\r\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\rX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\rX\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001a"}, d2 = {"Lcom/example/newsapp/utils/Constants;", "", "()V", "BUSINESS", "", "DATABASE_NAME", "DEFAULT_SWIPER_DELAY", "", "ENTERTAINMENT", "GENERAL", "HEALTH", "HOME", "INITIAL_POSITION", "", "NEWS_CONTENT", "NEWS_DESCRIPTION", "NEWS_IMAGE_URL", "NEWS_PUBLICATION_TIME", "NEWS_SOURCE", "NEWS_TITLE", "NEWS_URL", "SCIENCE", "SPORTS", "TECHNOLOGY", "TOP_HEADLINES_COUNT", "TOTAL_NEWS_TAB", "app_release"})
public final class Constants {
    @org.jetbrains.annotations.NotNull
    public static final com.example.newsapp.utils.Constants INSTANCE = null;
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String HOME = "Home";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String GENERAL = "general";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String SCIENCE = "science";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String HEALTH = "health";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String ENTERTAINMENT = "entertainment";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String BUSINESS = "business";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String TECHNOLOGY = "technology";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String SPORTS = "sports";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_URL = "news url";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_TITLE = "news title";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_IMAGE_URL = "news image url";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_SOURCE = "news source";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_PUBLICATION_TIME = "news publication time";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_DESCRIPTION = "news description";
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String NEWS_CONTENT = "news content";
    public static final int TOTAL_NEWS_TAB = 7;
    public static final int TOP_HEADLINES_COUNT = 5;
    @org.jetbrains.annotations.NotNull
    public static final java.lang.String DATABASE_NAME = "LOGIN_DATABASE";
    public static final long DEFAULT_SWIPER_DELAY = 4000L;
    public static final int INITIAL_POSITION = 0;
    
    private Constants() {
        super();
    }
}